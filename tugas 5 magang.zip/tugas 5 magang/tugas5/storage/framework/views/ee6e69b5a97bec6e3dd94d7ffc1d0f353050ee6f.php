
  
<?php $__env->startSection('title', 'Dashboard - Laravel Admin Panel With Login and Registration'); ?>
  
<?php $__env->startSection('contents'); ?>
  <div class="row">
    Dashboard
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugas5\resources\views/dashboard.blade.php ENDPATH**/ ?>