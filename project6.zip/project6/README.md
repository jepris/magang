# Blog Laravel WPU

🐘 Learn Laravel Framework with WPU by creating Blog System.

https://user-images.githubusercontent.com/75721128/158203792-6e13d89e-82b7-4a2f-b029-bfca059bc508.mp4

