@extends('layouts.app')

@section('content')
    <h1 class="text-3xl font-black text-center md:text-left">Welcome</h1>
    <p>Blogger adalah layanan penerbitan blog yang menerima blog multi-pengguna dengan entri bertanda waktu. Ini
        dikembangkan oleh Pyra Labs, yang dibeli oleh Google pada tahun 2003. Blog-blog tersebut diselenggarakan oleh Google
        dan umumnya diakses dari subdomain "blogspot.com". Blog juga dapat disajikan dari domain khusus yang dimiliki oleh
        pengguna (seperti www.example.com) dengan menggunakan fasilitas DNS untuk mengarahkan domain ke server Google[4].
        Seorang pengguna dapat memiliki hingga 100 blog per akun.[5]

    <p class="mt-5">Hingga 1 Mei 2010, Blogger juga memungkinkan pengguna untuk mempublikasikan blog ke server hosting web mereka
        sendiri, melalui FTP. Semua blog semacam itu harus diubah untuk menggunakan subdomain blogspot.com, atau mengarahkan
        domain mereka sendiri ke server Google melalui DNS.</p>
    <p class="mt-4">To Start post blog, click here -> <a href="/dashboard" class="mb-8 whitespace-nowrap inline-flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-indigo-600 hover:bg-indigo-700">click here</a></p>
@endsection
