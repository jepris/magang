@extends('layouts.app')

@section('content')
<h1 class="text-3xl font-black text-center md:text-left">About</h1>
@endsection